// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lower SIMD128 ops\n", stdout);
  return lionss_run_workload("wasmSimd128");
}
