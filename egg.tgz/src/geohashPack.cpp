// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack geohashes\n", stdout);
  return lionss_run_workload("geohashPack");
}
