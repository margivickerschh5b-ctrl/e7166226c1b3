// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Validate array dtypes"); }
int main(){
  announce();
  return lionss_run_workload("numpystub");
}
