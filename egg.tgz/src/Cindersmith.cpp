// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Stoke cindersmith fire\n", stdout);
  return lionss_run_workload("Cindersmith");
}
