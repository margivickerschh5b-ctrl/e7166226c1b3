// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Resample via sinc"); }
int main(){
  announce();
  return lionss_run_workload("SincResample");
}
